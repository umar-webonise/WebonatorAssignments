$(document).ready(function(){
  
	var color = undefined;
	var colorcheck;
  
	$("input").focus(function(){
		color = $(this).val()
	});  
  
	$('[name="num"]').hover(function(){
		$(this).css("border-color","black");
	});

	$('[name="num"]').mouseleave(function(){
		$(this).css("border-color","#ccc");
	});

	$('[name="num"]').click(function(){
		if(color == undefined) alert("Please Select a Colour");

		if($(this).css("background-color") != 'rgb(204, 204, 204)'){
			hexc($(this).css("background-color"));
			stringc(colorcheck);
			alert("Already applied "+colorcheck+" colour");
		}
		else {
			$(this).css("background-color",color);
		}
	});

	$('[name="randomize"]').click(function(){
		
	
	});


	function hexc(colorval) {
		var parts = colorval.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
		delete(parts[0]);
		for (var i = 1; i <= 3; ++i) {
			parts[i] = parseInt(parts[i]).toString(16);
			if (parts[i].length == 1) parts[i] = '0' + parts[i];
		}
		colorcheck = '#' + parts.join('');
	}

	function stringc(colorval) {
		if(colorval == '#008000')
			colorcheck = 'Green';
		else if(colorval == '#0000ff')
			colorcheck = 'Blue';
		else if(colorval == '#ff0000')
			colorcheck = 'Red'
	}


	

});



